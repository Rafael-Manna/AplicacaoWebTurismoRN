document.addEventListener("DOMContentLoaded", carregarRelatorio);

async function carregarRelatorio() {
    const conteudo = document.getElementById("conteudo");

    try {
        const resp = await fetch("http://localhost:3000/relatorios");
        const dados = await resp.json();

        if (!dados.sucesso) {
            document.getElementById("status").innerText =
                "Erro ao carregar relatório.";
            return;
        }

        // Agrupar por usuário
        const grupos = {};
        dados.dados.forEach(item => {
            if (!grupos[item.id_usuario]) {
                grupos[item.id_usuario] = {
                    nome: item.nome_usuario,
                    respostas: []
                };
            }
            grupos[item.id_usuario].respostas.push(item);
        });

        // Criar estrutura visual
        Object.values(grupos).forEach(usuario => {
            // Título do usuário
            const titulo = document.createElement("h2");
            titulo.classList.add("usuario-titulo");
            titulo.innerText = `👤 ${usuario.nome}`;
            conteudo.appendChild(titulo);

            // Tabela
            const tabela = document.createElement("table");
            tabela.classList.add("tabela-usuario");

            tabela.innerHTML = `
                <thead>
                    <tr>
                        <th>Pergunta</th>
                        <th>Resposta</th>
                    </tr>
                </thead>
                <tbody></tbody>
            `;

            const tbody = tabela.querySelector("tbody");

            usuario.respostas.forEach(r => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${r.texto_pergunta}</td>
                    <td>${r.resposta}</td>
                `;
                tbody.appendChild(tr);
            });

            conteudo.appendChild(tabela);
        });

    } catch (e) {
        console.error(e);
        document.getElementById("status").innerText = "Erro ao carregar dados.";
    }
}
